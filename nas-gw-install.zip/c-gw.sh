#!/usr/bin/env bash

cat >> /etc/systemd/system/c-gw.service <<EOF
[Unit]
Description=Openstack Customizing Gateway
After=network.target

[Service]
User=ubuntu
Group=ubuntu
LimitNOFILE=65535
ExecStart=/usr/bin/java -jar /home/ubuntu/c-gw.jar -Xmx1024M --spring.profiles.active=openstack-gw-internal
Restart=always
SuccessExitStatus=143

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl start c-gw
systemctl enable c-gw

