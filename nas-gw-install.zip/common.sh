#!/usr/bin/env bash

echo '>>>>> timezone를 서울로 변경'
timedatectl set-timezone Asia/Seoul

echo '>>>>> /etc/hosts에 cluster node name 설정 '
#5대 모두 아래 기입하여 공통 적용
cat >> /etc/hosts <<EOF
10.10.76.48 manila-c-api-gw01
10.10.76.49 manila-c-api-gw02
10.10.76.50 manila-c-api-gw03

10.10.76.51 manila-n-api-gw01
10.10.76.52 manila-n-api-gw02
EOF

echo '>>>>> jdk1.8 설치 '
apt-get -y install openjdk-8-jdk > /dev/null

echo '>>>>> JAVA_HOME 설정'
echo 'export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64' >> /etc/profile
source /etc/profile

