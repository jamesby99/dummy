#!/usr/bin/env bash

cat >> /etc/systemd/system/n-gw.service <<EOF
[Unit]
Description=Netapp API Gateway
After=network.target

[Service]
User=ubuntu
Group=ubuntu
LimitNOFILE=65535
ExecStart=/usr/bin/java -jar /home/ubuntu/n-gw.jar -Xmx1024M
Restart=always
SuccessExitStatus=143

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl start n-gw
systemctl enable n-gw

